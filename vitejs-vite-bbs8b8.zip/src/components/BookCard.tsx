import React from 'react';
import { Book } from '../types/book';

interface BookCardProps {
  book: Book;
}

export const BookCard: React.FC<BookCardProps> = ({ book }) => {
  const coverUrl = book.cover_i
    ? `https://covers.openlibrary.org/b/id/${book.cover_i}-M.jpg`
    : 'https://via.placeholder.com/200x300?text=No+Cover';

  return (
    <div className="flex flex-col bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <img
        src={coverUrl}
        alt={`Cover of ${book.title}`}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-800 mb-2">{book.title}</h3>
        {book.author_name && (
          <p className="text-sm text-gray-600 mb-2">
            By {book.author_name.join(', ')}
          </p>
        )}
        {book.first_publish_year && (
          <p className="text-sm text-gray-500">
            Published: {book.first_publish_year}
          </p>
        )}
        {book.publisher && book.publisher.length > 0 && (
          <p className="text-sm text-gray-500">
            Publisher: {book.publisher[0]}
          </p>
        )}
      </div>
    </div>
  );
};