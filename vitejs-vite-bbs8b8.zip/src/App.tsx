import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { SearchBar } from './components/SearchBar';
import { BookList } from './components/BookList';
import { searchBooks } from './services/api';

function App() {
  const [searchTerm, setSearchTerm] = useState('');

  const { data, isLoading, error } = useQuery({
    queryKey: ['books', searchTerm],
    queryFn: () => searchBooks(searchTerm),
    enabled: !!searchTerm,
  });

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold text-center text-gray-800 mb-8">
          📚 Book Finder
        </h1>
        <div className="flex justify-center mb-8">
          <SearchBar onSearch={setSearchTerm} />
        </div>
        <BookList
          books={data?.docs || []}
          isLoading={isLoading}
          error={error as Error}
        />
      </div>
    </div>
  );
}

export default App;