export interface Book {
  key: string;
  title: string;
  author_name?: string[];
  first_publish_year?: number;
  cover_i?: number;
  publisher?: string[];
  language?: string[];
  isbn?: string[];
}

export interface SearchResponse {
  numFound: number;
  docs: Book[];
}