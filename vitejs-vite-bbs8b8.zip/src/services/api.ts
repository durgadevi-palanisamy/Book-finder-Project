import axios from 'axios';
import { SearchResponse } from '../types/book';

const BASE_URL = 'https://openlibrary.org';

export const searchBooks = async (query: string): Promise<SearchResponse> => {
  const response = await axios.get(`${BASE_URL}/search.json`, {
    params: {
      q: query,
      limit: 20,
    },
  });
  return response.data;
};